![image](https://github.com/mzhkolk/SafeHeart/assets/72930961/b74bf147-ed28-44ef-9035-c6fd8b7c226c)
