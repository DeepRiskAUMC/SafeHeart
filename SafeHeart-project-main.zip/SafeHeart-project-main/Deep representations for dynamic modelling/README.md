![image](https://github.com/mzhkolk/SafeHeart/assets/72930961/acd056a8-7197-42e2-a0b2-6c41982c599f)
